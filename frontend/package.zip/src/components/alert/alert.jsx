import React, { Component } from 'react';
import { is, fromJS } from 'immutable';
import ReactDOM from 'react-dom';
import axios from 'axios';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import './alert.css';
 
 
let defaultState = {
  alertStatus:false,
  userID: "12345",
  rating: null,
  movieID: "",
  isSuccess: false,
  closeAlert:function(){}
}
 
class Alert extends Component{
 
  state = {
    ...defaultState
  };
  // css动画组件设置为目标组件
  FirstChild = props => {
    const childrenArray = React.Children.toArray(props.children);
    return childrenArray[0] || null;
  }
  // 关闭弹框
  confirm = () => {
    const _this = this;
    console.log("评分"+_this.state.userID);
    _this.setState({
      alertStatus:false,
      userID: document.getElementById("user").value,
      rating : document.getElementById("rating").value,
      movieID: document.getElementById("movieID").value
      
    })
    _this.state.closeAlert();
    console.log("评分"+_this.state.rating);
    console.log("评分"+_this.state.userID);
    console.log("评分"+_this.state.movieD);
    if(_this.state.rating !== null){
      axios.get(_this.props.source,{params:{userID:_this.props.params}},
          {
              params:{
                userID: _this.props.params1,
                movieID: _this.props.params2,
                rating: _this.props.params3
              }
          })
          .then(function (response) { 
            console.log("axios评分"+response.data.success);
          })
          .catch(function (error) {
            console.log(error);
          })
      }
  }

  open =(options)=>{
    options = options || {};
    options.alertStatus = true;
    this.setState({
      ...defaultState,
      ...options
    })
  }
  close(){
    this.state.closeAlert();
    console.log(this.state.rating);
    this.setState({
      ...defaultState
    })
  }
  shouldComponentUpdate(nextProps, nextState){
    return !is(fromJS(this.props), fromJS(nextProps)) || !is(fromJS(this.state), fromJS(nextState))
  }
   
  render(){
    return (
      <ReactCSSTransitionGroup
        component={this.FirstChild}
        transitionName='hide'
        transitionEnterTimeout={300}
        transitionLeaveTimeout={300}>
        <div className="alert-con" style={this.state.alertStatus? {display:'block'}:{display:'none'}}>
          <div className="alert-context">
            <div className="alert-content-detail">打个分吧：<input id="rating"></input></div>
            <div className="comfirm" onClick={this.confirm}>确定</div>
          </div>
        </div>
      </ReactCSSTransitionGroup>
    );
  }
}
 
let div = document.createElement('div');
let props = {
   
};
document.body.appendChild(div);
 
let Box = ReactDOM.render(React.createElement(
  Alert,
  props
),div);
 
 
 
export default Box;