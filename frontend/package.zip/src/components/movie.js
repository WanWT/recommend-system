import React from 'react';
import axios from 'axios';
import '../mock/mockdata';
import Alert from "./alert/alert.jsx";
require("../css/table.css");

class MovieRec extends React.Component 
{
    constructor(props){
      super(props);
      this.state = {
        isLoaded: false,
        movieName: '',
        movieID: '',
        genres: '',
        releaseDate: '',
        movieURL: ''                                                                                      
      };
    };

    getInitialState() {   
        return {
          movieName: '',
          movieID: '',
          genres: '',
          releaseDate: '',
          movieURL: ''     
        };
      };


      componentDidMount() {
        const _this = this;
        axios.get(_this.props.source,{params:{userID:_this.props.params}})
        .then(
          function(result) {
          var movie = result.data.data[0];
          console.log(result.data.data[0].movieID);
          _this.setState({
            isLoaded: true,
            movieID: movie.movieID,
            movieName: movie.movieName,
            genres: movie.genres,
            releaseDate: movie.releaseDate,
            movieURL: movie.imdbURL
          });
        })
        .catch(function (error) {
          console.log(error);
          _this.setState({
            isLoaded:false,
            error:error
          })
        });
      }

      open=()=>{
        Alert.open({
            closeAlert:function(){
                console.log("关闭了...");
            }
        });
    }
    
      render() {
        if(!this.state.isLoaded) return(<div>loading</div>)
        return (
          <div>
            为你推荐
            <table class="movie" fram="void">
            <tbody>
              <tr>
                <th>名称</th>
                <th id="movieID">编号</th>
                <th>类型</th>
                <th>发行日期</th>
                <th>评分</th>
              </tr>
              <tr>
                <td><a href={this.state.movieURL}>{this.state.movieName}</a></td>
                <td>{this.state.movieID}</td>
                <td>{this.state.genres}</td>
                <td>{this.state.releaseDate}</td>
                <td>
                  <button onClick={this.open}>看过</button>
                  <button><a href={this.state.movieURL}>想看</a></button>
                </td>  
              </tr>          
              
              </tbody>           
            </table>
          </div>
        );
      }
      
}

export default MovieRec;
